
# The system UUID, as captured by Ansible.
SYSTEM_UUID = '81069259-77b5-41c2-9e12-bab2dd3c8375'
